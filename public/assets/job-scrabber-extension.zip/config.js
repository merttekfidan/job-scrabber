// Extension configuration fallbacks
export const DEFAULT_CONFIG = {
    PROD_URL: 'https://aware-endurance-production-13b8.up.railway.app',
    DEV_URL: 'https://aware-endurance-production-13b8.up.railway.app',
    APP_NAME: 'Job Scrabber',
    VERSION: '2.0.0'
};
