// Extension configuration fallbacks
export const DEFAULT_CONFIG = {
    PROD_URL: 'https://huntiq.work',
    DEV_URL: 'https://huntiq.work',
    APP_NAME: 'HuntIQ',
    VERSION: '2.0.0'
};
