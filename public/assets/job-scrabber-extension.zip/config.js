// Extension configuration fallbacks
export const DEFAULT_CONFIG = {
    PROD_URL: 'https://huntiq.work',
    DEV_URL: 'https://aware-endurance-production-13b8.up.railway.app',
    APP_NAME: 'HuntIQ',
    VERSION: '2.0.0'
};
